import {NavBar} from '../Home.js'

export default function Page2() {
    return(
        <>
              <p>[11:04] Diane Robert</p>

        <h1>Page 2</h1>
        <NavBar />
        </>

    )
}
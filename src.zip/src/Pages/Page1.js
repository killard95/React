import {NavBar} from '../Home.js'

export default function Page1() {
    return(
        <>
              <p>[11:04] Diane Robert</p>

        <h1>Page 1</h1>
        <NavBar />
        </>
    )
}
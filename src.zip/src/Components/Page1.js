import FetchQuery from "./FetchQuery"
import {NavBar} from './Accueil'


export default function Page1() {
    return (
            <div>
                <NavBar />
                <FetchQuery />
            </div>
        )
}